//
// Created by 유영수 on 2017. 10. 26..
//

#include <com_ryla_rylatest_activity_Test2Activity.h>
#include "urqa.h"

void Crash() {
    int a = 1/0;
    /*volatile int* a = reinterpret_cast<volatile int*>(NULL);
    *a = 1;*/
}

JNIEXPORT jstring JNICALL
Java_com_ryla_rylatest_activity_Test2Activity_getJNIString(JNIEnv *env, jobject obj) {
    //Crash();#$$
    UrqaNative::URQAIntialize(env);
    Crash();
    //UrqaNative::JavaCallTest("/data/user/0/com.ryla.rylatest.dev/cache/2575dd61-d237-6cb5-16268660-4e132cf3.dmp");

    return env->NewStringUTF("CRASH!");
}
