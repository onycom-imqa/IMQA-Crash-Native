
class ImQALogger
{

public:
	ImQALogger();
	~ImQALogger();


public:
	static void log(char* msg);
};